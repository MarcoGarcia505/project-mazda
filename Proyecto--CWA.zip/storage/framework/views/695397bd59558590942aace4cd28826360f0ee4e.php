<!DOCTYPE html>
<html lang="en">
<head>
    <title>CWA</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="<?php echo e(url('public/images/icons/logo_cwa.svg')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/fonts/iconic/css/material-design-iconic-font.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/animate/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/css-hamburgers/hamburgers.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/animsition/css/animsition.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/select2/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/daterangepicker/daterangepicker.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/main.v1.css')); ?>">
</head>
<body>
<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100">
            <form method="post" action="<?php echo e(route('_login')); ?>" class="login100-form">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                <span class="login100-form-title p-b-50">
                    <i class=""> <img src="<?php echo e(url('public/images/icons/logo_cwa.png')); ?>" alt="logo cwa" class="logo_cwa"></i>
                </span>

                <div class="wrap-input100 validate-input" data-validate="Ingresar correo valido">
                    <input class="input100" type="text" name="email" value="">
                    <span class="focus-input100" data-placeholder="Email"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Ingresar una contraseña">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                    <input class="input100" type="password" name="password" value="">
                    <span class="focus-input100" data-placeholder="Password"></span>
                </div>

                
                <button type="submit" class="login100-form-btn">
                    <span class="bob">Login</span>
                </button>
                

                
            </form>
        </div>
    </div>
</div>
<script src="<?php echo e(url('public/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/animsition/js/animsition.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/bootstrap/js/popper.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/daterangepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/countdowntime/countdowntime.js')); ?>"></script>
<script src="<?php echo e(url('public/js/main-login.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Proyecto--CWA\resources\views/login.blade.php ENDPATH**/ ?>