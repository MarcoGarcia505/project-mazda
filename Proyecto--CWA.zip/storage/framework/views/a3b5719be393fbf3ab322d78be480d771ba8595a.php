<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('public/css/configuration.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascripts'); ?>
    <script src="<?php echo e(url('public/js/configuration.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5 pt-5">
        <h3 class="text-center"><?php echo e(trans('messages.template.configuration')); ?></h3>
        <?php if($errors->any()): ?>
            <div class="row mt-5">
                <div class="col-sm-12">
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row mt-5 mb-5">
            <div class="col-sm-12">
                <form action="<?php echo e(route('configuration')); ?>" method="post">
                    <div class="form-group">
                        <label for="video">Video URL</label>
                        <input type="text" class="form-control" value="<?php echo e($configuration->video_url); ?>" pattern="https?://.+" required id="video" name="video" aria-describedby="videoHelp" placeholder="Entre la URL del Video">
                        <small id="videoHelp" class="form-text text-muted">Ex. https://vimeo.com/video/vdx34de3</small>
                    </div>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                    <button type="submit" class="btn btn-primary text-uppercase">Actualizar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/14/d853376993/htdocs/web2/resources/views/configuration.blade.php ENDPATH**/ ?>